import numpy as np
from .Base import BaseLayer
class RNN(BaseLayer):

    def __init__(self, input_size, hidden_size, output_size):
        super(RNN, self).__init__()
        self.input_size = input_size
        self.hidden_size = hidden_size
        self.output_size = output_size
        self.hidden_state = np.zeros([1, self.hidden_size])
        self._memorize = False
        self.weights_hh = np.random.uniform(0,1, [self.hidden_size, self.hidden_size])
        self.weights_xh = np.random.uniform(0,1, [self.input_size, self.hidden_size])
        self.weights_hy = np.random.uniform(0, 1, [self.hidden_size, self.output_size])
        self.bias_h = np.random.uniform(0, 1, [1, self.hidden_size])
        self.bias_y = np.random.uniform(0, 1, [1, self.output_size])
        self.output_tensor = None


    @property
    def memorize(self):
        return self._memorize

    @memorize.setter
    def memorize(self, memorize):
        self._memorize = memorize


    def forward(self, input_tensor):
        self.input_tensor = input_tensor
        self.output_tensor = np.zeros((input_tensor.shape[0], self.output_size))
        for batch in range(input_tensor.shape[0]):
            self.hidden_state = np.tanh(np.dot(self.hidden_state, self.weights_hh) + np.dot(input_tensor[batch], self.weights_xh) + self.bias_h)
            self.output_tensor[batch] = 1/(1+np.exp(-(np.dot(self.hidden_state, self.weights_hy) + self.bias_y)))
        return self.output_tensor

    def backward(self, error_tensor):
        
