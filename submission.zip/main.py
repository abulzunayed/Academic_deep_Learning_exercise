import pattern
from generator import ImageGenerator

c = pattern.Circle(1024, 200, (512, 256))
c.draw()
c.show()
checker = pattern.Checker(100,10)
checker.draw()
checker.show()
spectrum = pattern.Spectrum(100)
spectrum.draw()
spectrum.show()

gen = ImageGenerator('./exercise_data', './Labels.json', 9, [32, 32, 3], rotation=True, mirroring=True, shuffle=True)
gen.show()
